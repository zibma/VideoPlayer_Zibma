package org.schabi.newpipe.extractor.services;

@SuppressWarnings("unused")
public interface BaseListExtractorTest extends BaseExtractorTest {
    void testRelatedItems() throws Exception;
    void testMoreRelatedItems() throws Exception;
}
